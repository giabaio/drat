#' This defines variables, mainly used with 'dplyr' and pipes that
#' throw a 'no visible binding for global variable' during
#' 'R CMD check' (before CRAN submission)
#'
#' @noRd
utils::globalVariables(names=c("event","."),add=FALSE)
