utils::globalVariables(c(
  ".",
  ":="
),add=FALSE)
